<?php
// Conexão com o banco de dados
include_once("./Tipo_Acesso/conexao.php");

// Verifica se o método é POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Pega os dados do formulário
    $cpf = trim($_POST["cpf_profissional"] ?? "");
    $usuario = trim($_POST["usuario"] ?? "");
    $nome = trim($_POST["nome"] ?? "");
    $senha = trim($_POST["senha"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $celular = trim($_POST["celular"] ?? "");

    // Verifica se todos os campos estão preenchidos
    if (empty($cpf) || empty($usuario) || empty($nome) || empty($senha) || empty($email) || empty($celular)) {
        echo json_encode(["status" => "erro", "mensagem" => "Preencha todos os campos!"]);
        exit;
    }

    $sql = "INSERT INTO profissional (cpf_profissional, usuario, nome, senha, email, celular)
            VALUES (?, ?, ?, ?, ?, ?)";

    // Prepara e executa com segurança
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $cpf, $usuario, $nome, $senha, $email, $celular);

    if ($stmt->execute()) {
        echo json_encode(["status" => "sucesso", "mensagem" => "Profissional cadastrado com sucesso!"]);
    } else {
        echo json_encode(["status" => "erro", "mensagem" => "Erro ao cadastrar: " . $stmt->error]);
    }

    // Fecha conexões
    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "erro", "mensagem" => "Método inválido!"]);
}
?>
